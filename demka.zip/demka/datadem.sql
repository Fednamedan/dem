-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.6-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `history_sale`
--

DROP TABLE IF EXISTS `history_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `history_sale` (
  `history_sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_date` date DEFAULT NULL,
  `product_count` int(11) DEFAULT NULL,
  `partners_partners_id` int(11) NOT NULL,
  `product_product_id` int(11) NOT NULL,
  PRIMARY KEY (`history_sale_id`,`partners_partners_id`,`product_product_id`),
  KEY `fk_history_sale_partners1_idx` (`partners_partners_id`),
  KEY `fk_history_sale_product1_idx` (`product_product_id`),
  CONSTRAINT `fk_history_sale_partners1` FOREIGN KEY (`partners_partners_id`) REFERENCES `partners` (`partners_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_history_sale_product1` FOREIGN KEY (`product_product_id`) REFERENCES `product` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_sale`
--

LOCK TABLES `history_sale` WRITE;
/*!40000 ALTER TABLE `history_sale` DISABLE KEYS */;
INSERT INTO `history_sale` VALUES (1,'2023-03-23',15500,1,1),(2,'2023-12-18',12350,1,3),(3,'2024-06-07',37400,1,4),(4,'2022-12-02',35000,2,2),(5,'2023-05-17',1250,2,4),(6,'2024-06-07',1000,2,3),(7,'2024-07-01',7550,2,1),(8,'2023-01-22',7250,3,1),(9,'2024-07-05',2500,3,2),(10,'2023-03-20',59050,4,4),(11,'2024-03-12',37200,4,3),(12,'2024-05-14',4500,4,4),(13,'2023-09-19',50000,5,3),(14,'2023-11-10',670000,5,4),(15,'2024-04-15',35000,5,1),(16,'2024-06-12',25000,5,2);
/*!40000 ALTER TABLE `history_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_type`
--

DROP TABLE IF EXISTS `material_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_type` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_type` varchar(200) DEFAULT NULL,
  `percent_defect` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_type`
--

LOCK TABLES `material_type` WRITE;
/*!40000 ALTER TABLE `material_type` DISABLE KEYS */;
INSERT INTO `material_type` VALUES (1,'Тип материала 1','0.1'),(2,'Тип материала 2','0.95'),(3,'Тип материала 3','0.28'),(4,'Тип материала 4','0.55'),(5,'Тип материала 5','0.34');
/*!40000 ALTER TABLE `material_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partners` (
  `partners_id` int(11) NOT NULL AUTO_INCREMENT,
  `partners_title` varchar(200) DEFAULT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `partners_email` varchar(200) DEFAULT NULL,
  `partners_phone` varchar(45) DEFAULT NULL,
  `addres_partners` varchar(200) DEFAULT NULL,
  `partners_inn` bigint(20) DEFAULT NULL,
  `partners_raiting` varchar(45) DEFAULT NULL,
  `partners_type_partners_type_id` int(11) NOT NULL,
  PRIMARY KEY (`partners_id`,`partners_type_partners_type_id`),
  KEY `fk_partners_partners_type1_idx` (`partners_type_partners_type_id`),
  CONSTRAINT `fk_partners_partners_type1` FOREIGN KEY (`partners_type_partners_type_id`) REFERENCES `partners_type` (`partners_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'Иванова Александра Ивановна','База Строитель','aleksandraivanova@ml.ru','493 123 45 67','652050, Кемеровская область, город Юрга, ул. Лесная, 15',2222455179,'7',1),(2,'Петров Василий Петрович','Паркет 29','vppetrov@vl.ru','987 123 56 78','164500, Архангельская область, город Северодвинск, ул. Строителей, 18',3333888520,'7',2),(3,'Соловьев Андрей Николаевич','Стройсервис','ansolovev@st.ru','812 223 32 00','188910, Ленинградская область, город Приморск, ул. Парковая, 21',4440391035,'7',3),(4,'Воробьева Екатерина Валерьевна','Ремонт и отделка','ekaterina.vorobeva@ml.ru','444 222 33 11','143960, Московская область, город Реутов, ул. Свободы, 51',1111520857,'5',4),(5,'Степанов Степан Сергеевич','МонтажПро','stepanov@stepan.ru','912 888 33 33','309500, Белгородская область, город Старый Оскол, ул. Рабочая, 122',5552431140,'10',1);
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners_type`
--

DROP TABLE IF EXISTS `partners_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `partners_type` (
  `partners_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `partners_typecol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`partners_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners_type`
--

LOCK TABLES `partners_type` WRITE;
/*!40000 ALTER TABLE `partners_type` DISABLE KEYS */;
INSERT INTO `partners_type` VALUES (1,'ЗАО'),(2,'ООО'),(3,'ПАО'),(4,'ОАО');
/*!40000 ALTER TABLE `partners_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_title` varchar(200) DEFAULT NULL,
  `product_article` int(11) DEFAULT NULL,
  `product_min_cost` double DEFAULT NULL,
  `product_type_product_type_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`product_type_product_type_id`),
  KEY `fk_product_product_type_idx` (`product_type_product_type_id`),
  CONSTRAINT `fk_product_product_type` FOREIGN KEY (`product_type_product_type_id`) REFERENCES `product_type` (`product_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Паркетная доска Ясень темный однополосная 14 мм',8758385,4456.9,1),(2,'Инженерная доска Дуб Французская елка однополосная 12 мм',8858958,7330.99,1),(3,'Ламинат Дуб дымчато-белый 33 класс 12 мм',7750282,1799.33,2),(4,'Ламинат Дуб серый 32 класс 8 мм с фаской',7028748,3890.41,2),(5,'Пробковое напольное клеевое покрытие 32 класс 4 мм',5012543,5450.59,3);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_type`
--

DROP TABLE IF EXISTS `product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_type` (
  `product_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_type` varchar(200) DEFAULT NULL,
  `product_ratio` double DEFAULT NULL,
  PRIMARY KEY (`product_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_type`
--

LOCK TABLES `product_type` WRITE;
/*!40000 ALTER TABLE `product_type` DISABLE KEYS */;
INSERT INTO `product_type` VALUES (1,'Ламинат',2.35),(2,'Массивная доска',5.15),(3,'Паркетная доска',4.34),(4,'Пробковое покрытие',1.5);
/*!40000 ALTER TABLE `product_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-16 11:39:52
